## Installation

    `pip install os_shedulingAlgo_utsav`

## USE

    from osalgopackage_utsav import BestShedulingAlgo

    instance=BestShedulingAlgo(pass the size of set of processes)
    instance.RunAndCompare()