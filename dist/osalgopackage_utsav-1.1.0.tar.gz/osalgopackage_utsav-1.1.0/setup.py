from setuptools import setup
setup(
    name="osalgopackage_utsav",
    version="1.1.0",
    description="Get an ides how OS Sheduling Algorithms Work on a set of Process",
    author="Utsav",
    packages=['osalgopackage_utsav'],
    install_requires=[]
)